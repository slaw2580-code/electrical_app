# electrical drawing detection2 > 2025-10-26 9:41pm
https://universe.roboflow.com/senior-project-nnpyu/electrical-drawing-detection2

Provided by a Roboflow user
License: CC BY 4.0

